# inputEmoji
jQuery plugin for inserting Emojis into html input

Load:

    <script src='https://ili4x.github.io/inputEmoji/inputEmoji.js'></script>

Usage:

    $('input').emoji();
    
Demo:

https://ili4x.github.io/inputEmoji/demo.html
